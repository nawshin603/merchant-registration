
Convert colors in hsl() notation to hex notation.

```css
color: hsl( 100, 50%, 50%);
```

```css
color: #6abf40;
```